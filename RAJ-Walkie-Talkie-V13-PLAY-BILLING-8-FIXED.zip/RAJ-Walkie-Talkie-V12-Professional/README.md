# RAJ Walkie Talkie V12 – Professional UI

This project was reconstructed from the supplied V11 signed AAB. The AAB contained the application's WebView asset `index.html` and privacy policy, so the V12 project preserves that HTML/Supabase/WebRTC feature layer and wraps it in a clean editable Android project.

## Preserved features
- Email/password login
- Google sign-in flow
- Create Office / Join Office
- Office code and QR flow
- My Offices
- Supabase Realtime presence and signaling
- WebRTC group voice
- Push-to-talk
- Live Conversation mode
- Group audio toggle and app volume
- Auto reconnect with configurable delay
- Connection settings shortcuts
- Group Admin panel, members and connection history
- Privacy Policy
- Google Play Billing permission retained for the existing Play Store configuration

## V12 changes
- Professional dark dashboard UI
- Improved cards, spacing, hierarchy and voice controls
- Version code 12 / version name 12.0
- Native Android WebView bridge for Wi-Fi, Hotspot, Bluetooth and Location settings
- Microphone permission request and foreground voice service hooks
- Removed `READ_PHONE_STATE` from the manifest because it is not needed by the WebView voice flow

## Important
The source code was not available inside the signed AAB. Therefore this is a reconstruction, not a byte-for-byte recovery of the original Android source. Test the V12 build in Google Play Internal testing before replacing any production track.


## V12.1 Incoming-call audio fix
This build adds Android telephony-state monitoring and audio-focus handling. When a normal cellular call starts ringing or becomes active, RAJ Walkie Talkie immediately mutes the remote group audio, disables the walkie microphone track, and abandons its audio focus so the normal phone ringtone/call audio can play normally. When the call ends, the app restores the walkie audio state and reconnects when appropriate. The app does not read or store the caller's phone number; `READ_PHONE_STATE` is used only for call-state detection.

The fix is in `MainActivity.java` and `AndroidManifest.xml`.

V12 audio-call fix: the Android wrapper no longer requests persistent transient VOICE_CALL audio focus for the whole walkie-talkie session. Cellular call-state detection still mutes the WebRTC remote stream and disables the microphone during RINGING/OFFHOOK, then restores the prior voice state after IDLE. This avoids suppressing the normal phone ringtone on devices where persistent voice-call audio focus interferes with telephony audio.


Build fix: Kotlin stdlib, stdlib-jdk7, and stdlib-jdk8 are pinned to 1.8.22 to avoid duplicate-class errors with older 1.6.21 runtime modules.


V13 Play Billing fix: upgraded Google Play Billing dependency to 8.0.0 and bumped versionCode/versionName to 13/13.0 to satisfy Google Play Console's Billing Library requirement.
