# V17 Production Voice Architecture

## Core
- Native `NativeVoiceService` owns the LiveKit Room.
- WebView is only UI/account/admin.
- LiveKit SFU replaces N-peer WebRTC mesh.
- Supabase Edge Function mints short-lived room tokens after membership verification.
- FCM is a wake/reconnect signal only; audio never travels through FCM.

## Session lifecycle
1. User joins an office while UI is visible and microphone permission is granted.
2. UI sends office ID + current Supabase access token to the native service.
3. Service stores the session state using Android encrypted preferences.
4. Service starts the microphone foreground service and connects to LiveKit with audio disabled.
5. PTT_DOWN enables the native microphone publication; PTT_UP disables it.
6. Remote audio remains native and does not depend on the WebView renderer.
7. Network loss disconnects the native room and retry/backoff reconnects when network returns.
8. Service recreation can restore the encrypted session state.
9. Logout/Stop Voice clears the session and stops the service.

## FCM wake
PTT wake should send a high-priority, user-visible message containing only office/event routing metadata. Android may wake the app for limited processing, but background microphone access remains subject to Android's foreground-service and while-in-use rules. Therefore FCM improves recovery/wake signaling; it is not a bypass or an absolute delivery guarantee.

## Production cloud configuration
- LiveKit Cloud or self-hosted LiveKit with TLS and TURN.
- Supabase `livekit-token` Edge Function with `LIVEKIT_WS_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`, and `SUPABASE_SERVICE_ROLE_KEY`.
- Firebase Android app for `com.raj.walkietalkie` and `google-services.json`.
- Supabase `ptt-wake` Edge Function with server-side FCM credentials.

## Test matrix
2 phones; screen-off 15/60 min; minimize; Wi-Fi/4G handover; airplane-mode recovery; incoming cellular call; 2/5/10/25 member rooms; logout; Stop Voice; battery optimization; Samsung/Pixel/Xiaomi/OnePlus.
