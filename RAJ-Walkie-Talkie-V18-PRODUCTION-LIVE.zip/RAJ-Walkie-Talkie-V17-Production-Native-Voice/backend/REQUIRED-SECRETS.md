# V17 Required Production Configuration

Server-only LiveKit secrets:
- LIVEKIT_WS_URL
- LIVEKIT_API_KEY
- LIVEKIT_API_SECRET
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY

Firebase:
- Register Android package `com.raj.walkietalkie`.
- Add the real `google-services.json` to `app/`.
- Store Firebase service-account credentials only on the server/Edge Function.

Required backend functions:
- `livekit-token`: verify Supabase session + office membership and mint a short-lived LiveKit token.
- `ptt-wake`: verify sender membership and send a high-priority user-visible `PTT_WAKE` to the other office members.
