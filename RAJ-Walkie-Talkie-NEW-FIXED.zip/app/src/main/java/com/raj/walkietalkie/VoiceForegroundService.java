package com.raj.walkietalkie;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

public class VoiceForegroundService extends Service {
    private static final String CHANNEL = "raj_voice";
    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "RAJ Voice", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Keeps the voice session active while RAJ Walkie Talkie is minimized.");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setContentTitle("RAJ Walkie Talkie").setContentText("Voice session active").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true);
        startForeground(1001, b.build());
        return START_STICKY;
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
