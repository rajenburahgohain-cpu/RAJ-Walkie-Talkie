# RAJ Walkie Talkie — NEW Native Android Build

This is a clean rebuild from scratch. It does **not** use WebView or browser `getUserMedia()` for microphone capture.

## Core architecture
- Native Android microphone capture through the WebRTC Android SDK.
- WebRTC peer-to-peer audio.
- Supabase Realtime WebSocket Broadcast is used only for signaling.
- Push-to-talk controls the native WebRTC audio track.
- Native Android audio mode and speaker/Bluetooth routing controls.
- Foreground microphone service/notification for an active voice session.
- Google STUN is configured as the initial ICE server. A production TURN service should be added for networks where direct peer connectivity fails.

## Supabase
Project URL and the publishable client key are configured in `MainActivity.java`. The secret key is not included.

## Important
This build is a clean foundation for the requested production features. Database-backed group limits, authenticated private channels, billing, ads, voice history storage, QR/referral and production TURN are separate modules and should be added after the native voice path is verified.
