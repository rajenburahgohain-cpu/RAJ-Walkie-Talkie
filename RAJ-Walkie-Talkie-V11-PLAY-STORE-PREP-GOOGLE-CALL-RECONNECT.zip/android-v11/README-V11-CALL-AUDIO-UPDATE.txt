RAJ Walkie Talkie V11 - Call Audio Safety Update

Added without removing the existing WebRTC/Supabase voice/PTT flow:
1. Native Android phone-call state monitoring (RINGING/OFFHOOK/IDLE).
2. During a normal mobile phone call, group microphone transmission is muted.
3. Group remote audio is muted while the phone call is active.
4. PTT is blocked while a phone call is active.
5. After the phone call ends, group audio/PTT can resume and auto-reconnect may run.
6. READ_PHONE_STATE runtime permission is requested for this feature.
7. Group Admin Panel now includes Auto-Reconnect time controls, including Custom 1-120 minutes.
8. Existing Custom Auto-Reconnect setting remains stored locally and is synchronized with the Group Admin Panel.

Important: Test normal incoming/outgoing SIM calls on the target Android phones. Android/OEM call-audio behavior can vary.
