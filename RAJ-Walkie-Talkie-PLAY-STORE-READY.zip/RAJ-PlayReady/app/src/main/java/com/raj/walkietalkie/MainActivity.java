package com.raj.walkietalkie;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.content.Intent;
import androidx.browser.customtabs.CustomTabsIntent;

/**
 * RAJ Walkie Talkie launcher.
 *
 * The verified HTTPS website remains the voice implementation. A Custom Tab
 * uses the device's browser/WebRTC engine, avoiding a second WebRTC stack.
 */
public final class MainActivity extends Activity {
    private static final String START_URL =
            "https://rajenburahgohain-cpu.github.io/RAJ-Walkie-Talkie/";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        openSite();
    }

    private void openSite() {
        Uri uri = Uri.parse(START_URL);
        try {
            CustomTabsIntent tabs = new CustomTabsIntent.Builder()
                    .setShowTitle(true)
                    .build();
            tabs.launchUrl(this, uri);
        } catch (Exception ignored) {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        }
    }
}
