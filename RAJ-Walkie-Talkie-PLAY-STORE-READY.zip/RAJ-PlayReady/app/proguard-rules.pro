# No custom R8 rules required.
