# RAJ Walkie Talkie — Play Store preparation

## Architecture
The Android app launches the verified HTTPS RAJ Walkie Talkie web application in an Android Custom Tab. Voice remains in the device browser/WebRTC engine, avoiding a second native/WebView WebRTC implementation.

Start URL:
https://rajenburahgohain-cpu.github.io/RAJ-Walkie-Talkie/

## Release configuration
- applicationId: com.raj.walkietalkie
- versionCode: 4
- versionName: 4.0.0
- minSdk: 23
- targetSdk: 36
- compileSdk: 36
- AGP: 8.13.2
- Gradle: 8.13
- Java: 17

## GitHub Actions outputs
The workflow builds:
- Debug APK for device testing
- Release AAB for Google Play

The release AAB produced by this source is unsigned unless Play/App signing credentials are supplied. For production publishing, use Google Play App Signing and a secure upload key/keystore.

## Before production submission
1. Upload `docs/privacy-policy.html` to a public HTTPS location and enter its public URL in Play Console.
2. Complete App content, Data safety, Content rating and target audience declarations.
3. Because the app uses microphone functionality, accurately declare the microphone use and provide reviewer instructions/test credentials where required.
4. Complete closed testing if the developer account is a new personal account subject to Google's testing requirement.
5. Upload the release AAB, not the debug APK, to the appropriate Play testing/production track.
