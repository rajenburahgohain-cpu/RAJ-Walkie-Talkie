RAJ Walkie Talkie V4
====================

V4 changes:
1. WebRTC signaling uses Supabase Realtime Presence for member discovery.
2. Supabase Realtime auth token is explicitly set before the private voice channel is joined.
3. Deterministic offer ownership prevents offer glare.
4. ICE candidate queues are preserved until remote description is set.
5. Reconnect/disconnect handling removes stale peers.
6. QR code is generated for every Office Code.
7. Active group members are shown with Supabase Presence.
8. Android WebView uses WebViewAssetLoader, giving the local app a secure HTTPS origin.
9. Android RECORD_AUDIO permission is requested and WebView audio capture is explicitly granted.
10. A microphone foreground service keeps the app process/voice feature active while minimized and shows an ongoing notification.

Important:
- This is a real WebView/Android foreground-service architecture, not a Custom Tab.
- A foreground service helps keep the app process and voice feature alive while minimized. Android still controls background execution; the notification is intentionally persistent.
- For private Supabase Realtime channels, the Supabase project must allow authenticated members of the Office topic to read/insert Broadcast and Presence messages. Supabase documents this through RLS policies on realtime.messages.
- The Android build uses Gradle 8.13 and Java 17.
