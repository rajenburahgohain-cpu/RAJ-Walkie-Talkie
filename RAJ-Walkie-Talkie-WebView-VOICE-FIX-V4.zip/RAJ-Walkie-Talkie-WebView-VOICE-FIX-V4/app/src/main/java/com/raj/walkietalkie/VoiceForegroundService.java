package com.raj.walkietalkie;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

public class VoiceForegroundService extends Service {
    private static final String CHANNEL_ID = "raj_walkie_voice";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("RAJ Walkie Talkie")
                .setContentText("Voice service is active for your Office group")
                .setSmallIcon(R.drawable.ic_stat_walkie)
                .setOngoing(true)
                .build();
        startForeground(4104, notification);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID, "Walkie Talkie Voice", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Keeps the voice connection active while the app is minimized.");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
