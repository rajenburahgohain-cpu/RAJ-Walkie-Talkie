# RAJ Walkie Talkie V13 – Play Billing 8 Final

V13 preserves the existing WebView/Supabase/WebRTC voice and Push-to-Talk implementation.

## Android release configuration
- versionCode: 14
- versionName: 14.0
- Play Billing Library: 8.0.0
- Kotlin runtime: 1.8.22
- Existing microphone / foreground voice service / WebRTC / PTT code preserved.

## Google Play note
The red Billing error shown for Version Code 12 belongs to the V12 AAB. This V13 project is Version Code 13 and explicitly uses Play Billing 8.0.0.

The deobfuscation message is a warning, not the Billing blocker.

Build the V13 release AAB from this source before uploading it to Internal testing.


## V14 background/reconnect hardening

V14 keeps the existing one-time Office membership and adds Android-supported background lifetime hardening:

- Foreground microphone service uses `START_STICKY`.
- A partial wake lock is held only while the user has explicitly started voice.
- Android network callbacks notify the WebView about network recovery/loss.
- WebRTC/WebView reconnect logic remains enabled after minimize and screen-off; the old `document.hidden` microphone block was removed.
- The service remains running when the launcher task is removed, subject to Android system policy.
- Battery-optimization handling is exposed through native settings when needed.

This does not bypass Android Force Stop, OEM restrictions, or Doze policy. For production-grade peer connectivity across difficult NATs, a properly authenticated TURN service should also be configured; STUN-only WebRTC cannot guarantee connectivity on every network.
