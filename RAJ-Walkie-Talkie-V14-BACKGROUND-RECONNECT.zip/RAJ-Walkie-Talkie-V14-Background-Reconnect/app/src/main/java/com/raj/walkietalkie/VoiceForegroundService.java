package com.raj.walkietalkie;

import android.app.*;
import android.content.*;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.*;
import androidx.core.app.NotificationCompat;

/**
 * Keeps the voice session's Android process alive while the user has explicitly
 * started the walkie-talkie voice service. WebRTC signalling/audio remains
 * owned by the WebView, while this foreground service supplies the Android
 * lifetime, notification and a partial wake lock needed for screen-off use.
 */
public class VoiceForegroundService extends Service {
    private static final String CHANNEL = "raj_voice";
    private static final int NOTIFICATION_ID = 1001;
    private PowerManager.WakeLock wakeLock;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        acquireWakeLock();
        registerNetworkCallback();
        startForeground(NOTIFICATION_ID, buildNotification("Voice connection is active"));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL, "RAJ Walkie Talkie Voice", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Keeps the walkie-talkie voice session available in the background.");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("RAJ Walkie Talkie")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "RAJWalkieTalkie::VoiceSession");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire();
            }
        } catch (Exception ignored) { }
    }

    private void registerNetworkCallback() {
        try {
            connectivityManager = getSystemService(ConnectivityManager.class);
            if (connectivityManager == null) return;
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    updateNotification("Network restored — reconnecting voice…");
                    MainActivity.notifyNativeNetworkState(true);
                }
                @Override public void onLost(Network network) {
                    updateNotification("Waiting for network — voice will reconnect automatically");
                    MainActivity.notifyNativeNetworkState(false);
                }
            };
            connectivityManager.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception ignored) { }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // START_STICKY is intentional: Android may recreate the foreground
        // service after a process kill. This is not a bypass for Force Stop.
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Do not stop the foreground service when the launcher task is removed.
        // Android still controls whether the service can remain alive.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        try {
            if (connectivityManager != null && networkCallback != null)
                connectivityManager.unregisterNetworkCallback(networkCallback);
        } catch (Exception ignored) { }
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
