# RAJ Walkie Talkie — Native Android Starter

This is the first native Android foundation.

Included:
- Kotlin Android project
- Saved active-group restoration
- Auto-start foreground voice-service skeleton
- Minimized/screen-off service architecture
- One PRESS & HOLD TO TALK control
- Runtime microphone/notification permissions
- Bluetooth permission preparation
- START_STICKY service behavior

Next phases:
1. Supabase Auth and group sync
2. WebRTC audio engine
3. TURN server fallback
4. Realtime signaling and PTT floor lock
5. Background incoming voice/event handling
6. Bluetooth local mode
7. Voice history, consent and retention
8. Group Admin Panel
9. Super Admin Panel
10. Plans, ads, billing and production testing

Important: this starter does NOT yet transmit real voice. WebRTC, signaling and TURN are the next implementation phase.
