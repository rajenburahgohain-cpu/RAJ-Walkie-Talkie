package com.raj.walkietalkie

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }
        val title = TextView(this).apply { text = "📻 RAJ Walkie Talkie"; textSize = 26f }
        val group = TextView(this).apply { textSize = 18f; setPadding(0, 28, 0, 12) }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 8, 0, 24) }
        val ptt = Button(this).apply {
            text = "PRESS & HOLD TO TALK"
            textSize = 20f
            isAllCaps = false
        }

        val id = AppPrefs.activeGroupId(this)
        group.text = if (id != null) "Active Group: ${AppPrefs.activeGroupName(this)}"
                     else "Active Group: No saved group"
        status.text = if (id != null) "🟢 Restoring group • Voice service starting..."
                      else "Select a group after login."

        layout.addView(title); layout.addView(group); layout.addView(status); layout.addView(ptt)
        setContentView(layout)

        if (id != null && AppPrefs.autoReconnect(this)) startVoiceService(id, AppPrefs.activeGroupName(this))

        ptt.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    status.text = "🔴 Transmitting..."
                    VoiceService.sendCommand(this, VoiceService.ACTION_PTT_START); true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    status.text = "🟢 PTT Ready"
                    VoiceService.sendCommand(this, VoiceService.ACTION_PTT_STOP); true
                }
                else -> true
            }
        }
    }

    private fun startVoiceService(id: String, name: String) {
        val intent = Intent(this, VoiceService::class.java)
            .putExtra(VoiceService.EXTRA_GROUP_ID, id)
            .putExtra(VoiceService.EXTRA_GROUP_NAME, name)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun requestPermissionsIfNeeded() {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        val missing = list.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
    }
}
