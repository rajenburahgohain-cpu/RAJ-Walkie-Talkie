package com.raj.walkietalkie

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class VoiceService : Service() {
    companion object {
        const val ACTION_PTT_START = "com.raj.walkietalkie.PTT_START"
        const val ACTION_PTT_STOP = "com.raj.walkietalkie.PTT_STOP"
        const val EXTRA_GROUP_ID = "group_id"
        const val EXTRA_GROUP_NAME = "group_name"
        private const val CHANNEL_ID = "walkie_voice"
        private const val NOTIFICATION_ID = 1001

        fun sendCommand(context: Context, action: String) {
            context.startService(Intent(context, VoiceService::class.java).setAction(action))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Voice service active"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PTT_START -> update("PTT transmitting")
            ACTION_PTT_STOP -> update("Voice service active • PTT ready")
        }
        return START_STICKY
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_walkie)
            .setContentTitle("RAJ Walkie Talkie")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .build()

    private fun update(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Walkie Talkie Voice", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
