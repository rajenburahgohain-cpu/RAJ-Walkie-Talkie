package com.raj.walkietalkie

import android.content.Context

object AppPrefs {
    private const val PREFS = "raj_walkie_prefs"
    private const val ACTIVE_GROUP_ID = "active_group_id"
    private const val ACTIVE_GROUP_NAME = "active_group_name"
    private const val AUTO_RECONNECT = "auto_reconnect"

    fun saveActiveGroup(context: Context, id: String, name: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ACTIVE_GROUP_ID, id)
            .putString(ACTIVE_GROUP_NAME, name)
            .putBoolean(AUTO_RECONNECT, true)
            .apply()
    }
    fun activeGroupId(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ACTIVE_GROUP_ID, null)
    fun activeGroupName(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ACTIVE_GROUP_NAME, "No group selected") ?: "No group selected"
    fun autoReconnect(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(AUTO_RECONNECT, true)
}
