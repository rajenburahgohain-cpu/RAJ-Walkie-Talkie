package com.raj.walkietalkie;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private static final int MIC_REQUEST = 1201;
    private static final int PHONE_REQUEST = 1202;
    private WebView webView;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private PhoneStateListener phoneStateListener;
    private PhoneStateCallback phoneStateCallback;
    private boolean voiceFocusHeld = false;
    private static volatile MainActivity activeInstance;
    private int previousAudioMode = AudioManager.MODE_NORMAL;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        activeInstance = this;
        webView = new WebView(this);
        setContentView(webView);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        setupCallAudioProtection();
        WebView.setWebContentsDebuggingEnabled(false);
        // Keep the WebView renderer important while the voice foreground service is active.
        // This reduces background renderer pressure on Android/OEM builds.
        if (Build.VERSION.SDK_INT >= 26) {
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
        }
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
                        request.deny();
                    } else request.grant(request.getResources());
                });
            }
        });
        webView.addJavascriptInterface(new NativeBridge(), "NativeBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }


    /**
     * Keeps normal cellular-call ringtone/telephony audio higher priority than
     * the walkie-talkie stream. While the voice session is active we request
     * transient audio focus; when Android reports an incoming/active call we
     * immediately mute the WebView audio, disable the microphone track, and
     * abandon our focus so the normal phone ringtone/call audio is not suppressed.
     */
    private void setupCallAudioProtection() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build();
            audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(attrs)
                    .setWillPauseWhenDucked(true)
                    .setOnAudioFocusChangeListener(change -> {
                        if (change == AudioManager.AUDIOFOCUS_LOSS ||
                            change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ||
                            change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
                            notifyPhoneAudioState(true);
                        } else if (change == AudioManager.AUDIOFOCUS_GAIN) {
                            notifyPhoneAudioState(false);
                        }
                    })
                    .build();
        }
        if (Build.VERSION.SDK_INT >= 31) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                registerModernPhoneStateListener();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, PHONE_REQUEST);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                registerLegacyPhoneStateListener();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, PHONE_REQUEST);
            }
        }
    }

    private void registerLegacyPhoneStateListener() {
        TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (tm == null) return;
        phoneStateListener = new PhoneStateListener() {
            @Override public void onCallStateChanged(int state, String phoneNumber) {
                if (state == TelephonyManager.CALL_STATE_RINGING) notifyPhoneAudioStateCode("RINGING");
                else if (state == TelephonyManager.CALL_STATE_OFFHOOK) notifyPhoneAudioStateCode("OFFHOOK");
                else if (state == TelephonyManager.CALL_STATE_IDLE) notifyPhoneAudioStateCode("IDLE");
            }
        };
        tm.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
    }

    private void registerModernPhoneStateListener() {
        if (Build.VERSION.SDK_INT < 31) return;
        TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (tm == null) return;
        final TelephonyManager telephonyManager = tm;
        phoneStateCallback = new PhoneStateCallback();
        telephonyManager.registerTelephonyCallback(getMainExecutor(), phoneStateCallback);
    }

    private void notifyPhoneAudioState(boolean callActive) {
        runOnUiThread(() -> {
            if (callActive) {
                abandonVoiceAudioFocus();
                webView.evaluateJavascript("window.onNativePhoneCallState&&window.onNativePhoneCallState('OFFHOOK')", null);
            } else {
                webView.evaluateJavascript("window.onNativePhoneCallState&&window.onNativePhoneCallState('IDLE')", null);
            }
        });
    }

    private void requestVoiceAudioFocus() {
        // Do not take transient VOICE_CALL audio focus for the whole walkie-talkie
        // session. On some Samsung/Android builds that can suppress or duck the
        // normal incoming-call ringtone. WebRTC/WebView audio is allowed to play
        // without a persistent app-owned focus request; when Android reports a
        // cellular call, we mute the remote stream and disable the mic instead.
        voiceFocusHeld = false;
    }

    private void abandonVoiceAudioFocus() {
        if (audioManager == null || !voiceFocusHeld) return;
        if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) audioManager.abandonAudioFocusRequest(audioFocusRequest);
        voiceFocusHeld = false;
    }

    private void notifyPhoneAudioStateCode(String state) {
        runOnUiThread(() -> {
            if ("RINGING".equals(state) || "OFFHOOK".equals(state)) {
                try { previousAudioMode = audioManager.getMode(); audioManager.setMode(AudioManager.MODE_NORMAL); } catch (Exception ignored) {}
            } else if ("IDLE".equals(state)) {
                try { audioManager.setMode(previousAudioMode); } catch (Exception ignored) {}
            }
            boolean active = "RINGING".equals(state) || "OFFHOOK".equals(state);
            if (active) abandonVoiceAudioFocus();
            webView.evaluateJavascript("window.onNativePhoneCallState&&window.onNativePhoneCallState('"+state+"')", null);
        });
    }

    private class PhoneStateCallback extends android.telephony.TelephonyCallback implements android.telephony.TelephonyCallback.CallStateListener {
        @Override public void onCallStateChanged(int state) {
            if (state == TelephonyManager.CALL_STATE_RINGING) notifyPhoneAudioStateCode("RINGING");
            else if (state == TelephonyManager.CALL_STATE_OFFHOOK) notifyPhoneAudioStateCode("OFFHOOK");
            else if (state == TelephonyManager.CALL_STATE_IDLE) notifyPhoneAudioStateCode("IDLE");
        }
    }

    private void requestMic() {
        if (Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            webView.evaluateJavascript("window.onNativeMicPermissionGranted&&window.onNativeMicPermissionGranted()", null);
        } else if (requestCode == PHONE_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 31) registerModernPhoneStateListener();
            else registerLegacyPhoneStateListener();
        }
    }

    private void launchSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    /** Called by the foreground service to keep the WebView voice session healthy. */
    public static void notifyNativeBackgroundHeartbeat() {
        MainActivity a = activeInstance;
        if (a == null || a.webView == null) return;
        a.runOnUiThread(() -> {
            try {
                a.webView.evaluateJavascript(
                        "window.onNativeBackgroundHeartbeat&&window.onNativeBackgroundHeartbeat()",
                        null
                );
            } catch (Exception ignored) { }
        });
    }

    /** Called by the foreground service when Android reports a network change. */
    public static void notifyNativeNetworkState(boolean online) {
        MainActivity a = activeInstance;
        if (a == null || a.webView == null) return;
        a.runOnUiThread(() -> {
            try {
                String js = "window.onNativeNetworkState&&window.onNativeNetworkState(" + (online ? "true" : "false") + ")";
                a.webView.evaluateJavascript(js, null);
            } catch (Exception ignored) { }
        });
    }

    private void openBatteryOptimizationSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        } catch (Exception e) {
            launchSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS);
        }
    }


    private void registerFcmTokenInternal(String accessToken) {
        if (accessToken == null || accessToken.trim().isEmpty()) return;

        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(token -> new Thread(() -> {
                    HttpURLConnection connection = null;
                    try {
                        URL url = new URL(
                                "https://nxpagmvyoylhtprzccxs.supabase.co/rest/v1/rpc/register_device_token"
                        );
                        connection = (HttpURLConnection) url.openConnection();
                        connection.setRequestMethod("POST");
                        connection.setConnectTimeout(10000);
                        connection.setReadTimeout(10000);
                        connection.setDoOutput(true);
                        connection.setRequestProperty("apikey", "sb_publishable_AT6zontM3G2V3a0dYfzaBQ_nq6K4ozm");
                        connection.setRequestProperty("Authorization", "Bearer " + accessToken);
                        connection.setRequestProperty("Content-Type", "application/json");
                        connection.setRequestProperty("Accept", "application/json");

                        JSONObject body = new JSONObject();
                        body.put("p_token", token);
                        body.put("p_platform", "android");
                        body.put("p_app_version", "18.0");

                        try (OutputStream output = connection.getOutputStream()) {
                            output.write(body.toString().getBytes("UTF-8"));
                        }

                        int responseCode = connection.getResponseCode();
                        if (responseCode < 200 || responseCode >= 300) {
                            android.util.Log.w("RAJ_FCM", "FCM token registration failed: HTTP " + responseCode);
                        }
                    } catch (Exception e) {
                        android.util.Log.w("RAJ_FCM", "FCM token registration failed", e);
                    } finally {
                        if (connection != null) connection.disconnect();
                    }
                }).start())
                .addOnFailureListener(e ->
                        android.util.Log.w("RAJ_FCM", "Unable to obtain FCM token", e)
                );
    }

    public class NativeBridge {
        @JavascriptInterface public void openWifiSettings(){ launchSettings(Settings.ACTION_WIFI_SETTINGS); }
        @JavascriptInterface public void openHotspotSettings(){ launchSettings(Settings.ACTION_WIRELESS_SETTINGS); }
        @JavascriptInterface public void openBluetoothSettings(){ launchSettings(Settings.ACTION_BLUETOOTH_SETTINGS); }
        @JavascriptInterface public void openLocationSettings(){ launchSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS); }
        @JavascriptInterface public void openInternetSettings(){ launchSettings(Settings.ACTION_WIRELESS_SETTINGS); }
        @JavascriptInterface public void openBatteryOptimizationSettings(){ MainActivity.this.openBatteryOptimizationSettings(); }
        @JavascriptInterface public void requestMicrophone(){ requestMic(); }
        @JavascriptInterface public void startVoiceService(){
            // Legacy heartbeat service is no longer used for production voice.
            // NativeVoiceService owns the actual LiveKit audio session.
        }
        @JavascriptInterface public void stopVoiceService(){
            abandonVoiceAudioFocus();
            sendNativeProductionVoice(NativeVoiceService.ACTION_STOP);
        }
        @JavascriptInterface public void startNativeProductionVoice(String officeId, String accessToken, String refreshToken){
            startNativeProductionVoiceWithRefresh(officeId, accessToken, refreshToken);
        }
        @JavascriptInterface public void nativePttDown(){ sendNativeProductionVoice(NativeVoiceService.ACTION_PTT_DOWN); }
        @JavascriptInterface public void nativePttUp(){ sendNativeProductionVoice(NativeVoiceService.ACTION_PTT_UP); }
        @JavascriptInterface public void registerFcmToken(String accessToken){ registerFcmTokenInternal(accessToken); }
        @JavascriptInterface public void stopNativeProductionVoice(){ sendNativeProductionVoice(NativeVoiceService.ACTION_STOP); }
    }

    @Override protected void onResume() {
        super.onResume();
        activeInstance = this;
        if (webView != null) {
            try { webView.onResume(); } catch (Exception ignored) { }
            webView.postDelayed(() -> {
                try {
                    webView.evaluateJavascript(
                            "window.onNativeAppResumed&&window.onNativeAppResumed()",
                            null
                    );
                } catch (Exception ignored) { }
            }, 150);
        }
    }

    @Override protected void onDestroy(){
        if (activeInstance == this) activeInstance = null;
        abandonVoiceAudioFocus();
        try {
            TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (tm != null && Build.VERSION.SDK_INT >= 31 && phoneStateCallback != null) {
                tm.unregisterTelephonyCallback(phoneStateCallback);
            }
            if (tm != null && phoneStateListener != null && Build.VERSION.SDK_INT < 31) tm.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }

    private void startNativeProductionVoiceWithRefresh(String officeId, String accessToken, String refreshToken) {
        if (officeId == null || officeId.trim().isEmpty() || accessToken == null || accessToken.trim().isEmpty()) return;
        Intent i = new Intent(this, NativeVoiceService.class);
        i.setAction(NativeVoiceService.ACTION_START);
        i.putExtra(NativeVoiceService.EXTRA_OFFICE_ID, officeId);
        i.putExtra(NativeVoiceService.EXTRA_ACCESS_TOKEN, accessToken);
        i.putExtra(NativeVoiceService.EXTRA_REFRESH_TOKEN, refreshToken);
        try { ContextCompat.startForegroundService(this, i); } catch (Exception e) {
            // Android requires a visible activity for microphone FGS startup in the normal case.
            // Do not hide the failure; the UI can ask the user to reopen the app.
            try { setVoiceStartFailureState(); } catch (Exception ignored) {}
        }
    }

    private void setVoiceStartFailureState() {
        if (webView == null) return;
        webView.evaluateJavascript("window.onNativeVoiceStartFailed&&window.onNativeVoiceStartFailed()", null);
    }

    private void sendNativeProductionVoice(String action) {
        Intent i = new Intent(this, NativeVoiceService.class);
        i.setAction(action);
        try { startService(i); } catch (Exception ignored) {}
    }
}
