package com.raj.walkietalkie;

import android.app.*;
import android.content.*;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.*;
import androidx.core.app.NotificationCompat;

/**
 * Android-supported foreground lifetime for the walkie-talkie voice session.
 * WebRTC/signalling remain in the WebView; this service provides the native
 * foreground lifetime, network callbacks, wake lock and background health tick.
 */
public class VoiceForegroundService extends Service {
    private static final String CHANNEL = "raj_voice";
    private static final int NOTIFICATION_ID = 1001;
    private static final long HEARTBEAT_MS = 15000L;

    private PowerManager.WakeLock wakeLock;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            try { MainActivity.notifyNativeBackgroundHeartbeat(); } catch (Exception ignored) { }
            handler.postDelayed(this, HEARTBEAT_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        acquireWakeLock();
        registerNetworkCallback();
        startForeground(NOTIFICATION_ID, buildNotification("Voice connection is active"));
        handler.post(heartbeat);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL, "RAJ Walkie Talkie Voice", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Keeps the walkie-talkie voice session available in the background.");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("RAJ Walkie Talkie")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(
                        PowerManager.PARTIAL_WAKE_LOCK,
                        "RAJWalkieTalkie::VoiceSession");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire();
            }
        } catch (Exception ignored) { }
    }

    private void registerNetworkCallback() {
        try {
            connectivityManager = getSystemService(ConnectivityManager.class);
            if (connectivityManager == null) return;

            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    updateNotification("Network restored — reconnecting voice…");
                    MainActivity.notifyNativeNetworkState(true);
                }

                @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                    if (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                        MainActivity.notifyNativeNetworkState(true);
                    }
                }

                @Override public void onLost(Network network) {
                    updateNotification("Waiting for network — voice will reconnect automatically");
                    MainActivity.notifyNativeNetworkState(false);
                }
            };

            connectivityManager.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception ignored) { }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // A user explicitly swiping the task away is treated as an intentional
        // app close. This fixes the previous V14 behaviour where the foreground
        // service kept the app alive after the task was removed.
        handler.removeCallbacksAndMessages(null);
        try {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } catch (Exception ignored) {
            stopForeground(true);
        }
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try {
            if (connectivityManager != null && networkCallback != null)
                connectivityManager.unregisterNetworkCallback(networkCallback);
        } catch (Exception ignored) { }
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
