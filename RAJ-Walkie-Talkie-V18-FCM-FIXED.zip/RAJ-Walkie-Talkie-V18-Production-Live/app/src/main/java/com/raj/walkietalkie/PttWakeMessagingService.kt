package com.raj.walkietalkie

import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class PttWakeMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        getSharedPreferences("fcm", MODE_PRIVATE).edit().putString("token", token).apply()
        // The app registers the token with Supabase while the authenticated UI session is available.
    }

    override fun onMessageReceived(message: RemoteMessage) {
        if (message.data["type"] != "PTT_WAKE") return
        // High priority is required for the Android FGS background-start exemption.
        // If Google has downgraded the message, do not force a microphone FGS start.
        if (message.priority != RemoteMessage.PRIORITY_HIGH) {
            Log.w("RAJ_PTT_WAKE", "PTT_WAKE received without HIGH priority; opening a notification is preferred")
            return
        }
        val i = Intent(this, NativeVoiceService::class.java).apply { action = NativeVoiceService.ACTION_NETWORK_UP }
        try { ContextCompat.startForegroundService(this, i) }
        catch (e: Exception) { Log.w("RAJ_PTT_WAKE", "Native voice wake rejected by Android", e) }
    }
}
