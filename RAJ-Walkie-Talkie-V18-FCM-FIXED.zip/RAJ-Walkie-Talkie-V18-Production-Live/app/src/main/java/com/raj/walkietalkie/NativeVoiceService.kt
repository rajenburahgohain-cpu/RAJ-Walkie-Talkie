package com.raj.walkietalkie

import android.app.*
import android.content.*
import android.net.*
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import io.livekit.android.ConnectOptions
import io.livekit.android.LiveKit
import io.livekit.android.RoomOptions
import io.livekit.android.room.Room
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.min

/**
 * Production voice owner. The WebView is UI only; this service owns LiveKit,
 * microphone publication and reconnect while the activity is minimized.
 */
class NativeVoiceService : Service() {
    companion object {
        const val ACTION_START = "com.raj.walkietalkie.voice.START"
        const val ACTION_STOP = "com.raj.walkietalkie.voice.STOP"
        const val ACTION_PTT_DOWN = "com.raj.walkietalkie.voice.PTT_DOWN"
        const val ACTION_PTT_UP = "com.raj.walkietalkie.voice.PTT_UP"
        const val ACTION_NETWORK_UP = "com.raj.walkietalkie.voice.NETWORK_UP"
        const val EXTRA_OFFICE_ID = "office_id"
        const val EXTRA_ACCESS_TOKEN = "access_token"
        const val EXTRA_REFRESH_TOKEN = "refresh_token"
        private const val CHANNEL = "raj_native_voice"
        private const val NOTIFICATION_ID = 1701
        private const val SUPABASE_URL = "https://nxpagmvyoylhtprzccxs.supabase.co"
        private const val SUPABASE_KEY = "sb_publishable_AT6zontM3G2V3a0dYfzaBQ_nq6K4ozm"
        private const val TOKEN_ENDPOINT = "$SUPABASE_URL/functions/v1/livekit-token"
        private const val PREFS = "native_voice_session"

        fun start(context: Context, officeId: String, accessToken: String, refreshToken: String?) {
            val i = Intent(context, NativeVoiceService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_OFFICE_ID, officeId)
                putExtra(EXTRA_ACCESS_TOKEN, accessToken)
                putExtra(EXTRA_REFRESH_TOKEN, refreshToken)
            }
            try { androidx.core.content.ContextCompat.startForegroundService(context, i) }
            catch (_: Exception) { }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connectMutex = Mutex()
    private var room: Room? = null
    private var sessionJob: Job? = null
    private var officeId: String? = null
    private var accessToken: String? = null
    private var refreshToken: String? = null
    private var desiredSession = false
    private var networkAvailable = true
    private var desiredPtt = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Office voice starting…"))
        acquireWakeLock()
        registerNetworkCallback()
        restoreSession()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val o = intent.getStringExtra(EXTRA_OFFICE_ID)
                val a = intent.getStringExtra(EXTRA_ACCESS_TOKEN)
                val r = intent.getStringExtra(EXTRA_REFRESH_TOKEN)
                if (!o.isNullOrBlank() && !a.isNullOrBlank()) {
                    officeId = o; accessToken = a; refreshToken = r
                    desiredSession = true
                    persistSession()
                    ensureConnected("start")
                }
            }
            ACTION_PTT_DOWN -> { desiredPtt = true; scope.launch { setPtt(true) } }
            ACTION_PTT_UP -> { desiredPtt = false; scope.launch { setPtt(false) } }
            ACTION_NETWORK_UP -> ensureConnected("wake")
            ACTION_STOP -> stopVoiceSession()
        }
        return START_STICKY
    }

    private fun encryptedPrefs() = EncryptedSharedPreferences.create(
        this, PREFS,
        MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun persistSession() {
        try { encryptedPrefs().edit()
            .putString("office_id", officeId)
            .putString("access_token", accessToken)
            .putString("refresh_token", refreshToken)
            .apply()
        } catch (_: Exception) { }
    }

    private fun restoreSession() {
        try {
            val p = encryptedPrefs()
            officeId = p.getString("office_id", null)
            accessToken = p.getString("access_token", null)
            refreshToken = p.getString("refresh_token", null)
            desiredSession = !officeId.isNullOrBlank() && !accessToken.isNullOrBlank()
            if (desiredSession) ensureConnected("restore")
        } catch (_: Exception) { }
    }

    private fun clearSession() { try { encryptedPrefs().edit().clear().apply() } catch (_: Exception) {} }

    private fun ensureConnected(reason: String) {
        if (!desiredSession || !networkAvailable || sessionJob?.isActive == true) return
        sessionJob = scope.launch {
            var backoff = 1000L
            while (desiredSession && networkAvailable) {
                try {
                    connectMutex.withLock { if (room == null) connectRoom() }
                    backoff = 1000L
                    while (desiredSession && networkAvailable && room != null) delay(5000L)
                } catch (t: Throwable) {
                    disconnectRoom()
                    updateNotification("Voice reconnecting…")
                    delay(backoff)
                    backoff = min(backoff * 2, 30000L)
                }
            }
        }
    }

    private suspend fun connectRoom() {
        val office = officeId ?: error("Missing office")
        val bearer = ensureFreshSupabaseToken()
        updateNotification("Connecting to office voice…")
        val c = fetchToken(office, bearer)
        val r = LiveKit.create(applicationContext, RoomOptions(adaptiveStream = true, dynacast = true))
        r.connect(c.serverUrl, c.token, ConnectOptions(autoSubscribe = true, audio = false, video = false))
        room = r
        updateNotification(if (desiredPtt) "Office voice connected — TALKING" else "Office voice ready — PTT available")
        if (desiredPtt) r.localParticipant.setMicrophoneEnabled(true)
    }

    private suspend fun setPtt(enabled: Boolean) {
        if (!desiredSession) return
        repeat(4) { attempt ->
            try {
                val r = room
                if (r == null) { ensureConnected("ptt"); delay(700L + attempt * 500L); return@repeat }
                if (desiredPtt != enabled) return
                r.localParticipant.setMicrophoneEnabled(enabled)
                updateNotification(if (enabled) "TALKING — release PTT" else "Office voice ready — PTT available")
                return
            } catch (_: Throwable) {
                disconnectRoom()
                ensureConnected("ptt-retry")
                delay((attempt + 1) * 700L)
            }
        }
    }

    private suspend fun ensureFreshSupabaseToken(): String {
        val current = accessToken ?: error("Missing access token")
        if (!isJwtNearExpiry(current, 120)) return current
        val refresh = refreshToken ?: return current
        try {
            val c = (URL("$SUPABASE_URL/auth/v1/token?grant_type=refresh_token").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 10000; readTimeout = 15000; doOutput = true
                setRequestProperty("apikey", SUPABASE_KEY)
                setRequestProperty("Content-Type", "application/json")
            }
            c.outputStream.use { it.write(JSONObject().put("refresh_token", refresh).toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("Supabase refresh HTTP $code")
            val j = JSONObject(body)
            accessToken = j.getString("access_token")
            j.optString("refresh_token", refresh).takeIf { it.isNotBlank() }?.let { refreshToken = it }
            persistSession()
            return accessToken!!
        } catch (e: Exception) {
            throw IllegalStateException("Supabase session refresh failed", e)
        }
    }

    private fun isJwtNearExpiry(jwt: String, marginSeconds: Long): Boolean {
        return try {
            val part = jwt.split('.')[1]
            val padded = part.padEnd(((part.length + 3) / 4) * 4, '=')
            val bytes = android.util.Base64.decode(padded, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP)
            val exp = JSONObject(String(bytes, Charsets.UTF_8)).optLong("exp", 0L)
            exp == 0L || exp <= (System.currentTimeMillis() / 1000L + marginSeconds)
        } catch (_: Exception) { true }
    }

    private fun fetchToken(office: String, bearer: String): Credentials {
        val c = (URL(TOKEN_ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 10000; readTimeout = 15000; doOutput = true
            setRequestProperty("Authorization", "Bearer $bearer")
            setRequestProperty("apikey", SUPABASE_KEY)
            setRequestProperty("Content-Type", "application/json")
        }
        c.outputStream.use { it.write(JSONObject().put("office_id", office).toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) error("Token endpoint HTTP $code")
        val j = JSONObject(body)
        return Credentials(j.getString("server_url"), j.getString("token"))
    }

    private data class Credentials(val serverUrl: String, val token: String)

    private fun stopVoiceSession() {
        desiredSession = false; desiredPtt = false
        sessionJob?.cancel(); disconnectRoom(); clearSession()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun disconnectRoom() {
        try { room?.localParticipant?.setMicrophoneEnabled(false) } catch (_: Exception) {}
        try { room?.disconnect() } catch (_: Exception) {}
        try { room?.release() } catch (_: Exception) {}
        room = null
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { networkAvailable = true; ensureConnected("network") }
            override fun onLost(network: Network) {
                networkAvailable = false
                updateNotification("Network lost — waiting to reconnect")
                disconnectRoom()
            }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) { networkAvailable = true; ensureConnected("validated") }
            }
        }
        try { cm.registerDefaultNetworkCallback(networkCallback!!) } catch (_: Exception) {}
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RAJWalkieTalkie::NativeVoice")
            wakeLock?.setReferenceCounted(false); wakeLock?.acquire()
        } catch (_: Exception) {}
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)?.createNotificationChannel(
            NotificationChannel(CHANNEL, "RAJ Voice", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String): Notification {
        val i = Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP) }
        val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("RAJ Walkie Talkie")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).setOnlyAlertOnce(true).build()
    }

    private fun updateNotification(text: String) { getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, notification(text)) }

    override fun onDestroy() {
        desiredSession = false; sessionJob?.cancel(); disconnectRoom()
        try { getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(networkCallback!!) } catch (_: Exception) {}
        try { wakeLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
