# RAJ Walkie Talkie V18 — Production Native Voice

V18 moves the critical voice media path out of the WebView/P2P layer into a native Android foreground service using LiveKit's native Android WebRTC SDK. The WebView remains the UI/account/admin layer.

Target architecture:
WebView UI -> NativeVoiceService -> LiveKit SFU -> group members
                                  ^
                                  |
                                 FCM

LiveKit Android 2.29.0 is the native media engine. It supports native audio, room reconnect and ICE/TURN handling; the current SDK release is 2.29.0.

The package is an integration-ready production architecture, not a claim that cloud voice is already live. Real voice requires a deployed LiveKit server and the supplied Supabase token function; PTT wake requires a Firebase project, `google-services.json`, device-token registration and a server-side FCM sender. No private cloud credentials are hard-coded.

Android 14+ imposes foreground-service and while-in-use microphone restrictions. High-priority FCM can attempt to wake a sleeping device, but it is not a guarantee that a background microphone service can be started without user interaction. Force-stop, denied permissions, disabled notifications and OEM background policies cannot be bypassed.


## V18 production-live configuration
- NativeVoiceService is the sole production voice engine; WebView P2P audio is disabled.
- Supabase access/refresh session is encrypted locally for long-running reconnects.
- LiveKit native Android room uses auto-subscribe and publishes microphone only while PTT is held.
- Network changes trigger reconnect with exponential backoff.
- FCM PTT wake is treated as a wake/reconnect signal and respects Android foreground-service restrictions.
- Run `backend/supabase/device_tokens.sql` in Supabase and deploy the token/wake backend before expecting PTT wake across sleeping devices.
- Add the Firebase `google-services.json` configuration as the `GOOGLE_SERVICES_JSON_B64` GitHub secret for release builds.
