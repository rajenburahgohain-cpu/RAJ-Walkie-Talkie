// Production token endpoint TEMPLATE.
// Deploy as a Supabase Edge Function after adding the required server secrets.
// Never put LIVEKIT_API_SECRET in the Android app.

import { createClient } from "npm:@supabase/supabase-js@2";
import { AccessToken } from "npm:livekit-server-sdk";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type, apikey",
  "Content-Type": "application/json",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: cors });
  }

  try {
    const authHeader = req.headers.get("authorization") ?? "";
    const accessToken = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!accessToken) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), { status: 401, headers: cors });
    }

    const body = await req.json();
    const officeId = String(body.office_id ?? "");
    if (!officeId) {
      return new Response(JSON.stringify({ error: "Missing office_id" }), { status: 400, headers: cors });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { global: { headers: { Authorization: `Bearer ${accessToken}` } } },
    );

    const { data: userData, error: userError } = await supabase.auth.getUser(accessToken);
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid Supabase session" }), { status: 401, headers: cors });
    }

    // Reuse the existing membership RPC so the LiveKit room follows the same
    // office authorization rules as the current application.
    const { data: offices, error: officeError } = await supabase.rpc("get_my_offices");
    if (officeError) throw officeError;

    const membership = (offices ?? []).find((o: any) => String(o.office_id) === officeId);
    if (!membership) {
      return new Response(JSON.stringify({ error: "Not a member of this office" }), { status: 403, headers: cors });
    }

    const apiKey = Deno.env.get("LIVEKIT_API_KEY");
    const apiSecret = Deno.env.get("LIVEKIT_API_SECRET");
    const wsUrl = Deno.env.get("LIVEKIT_WS_URL");
    if (!apiKey || !apiSecret || !wsUrl) {
      throw new Error("LiveKit server secrets are not configured");
    }

    const identity = userData.user.id;
    const roomName = `office_${officeId}`;

    const token = new AccessToken(apiKey, apiSecret, {
      identity,
      name: userData.user.email ?? identity,
      ttl: "10m",
    });

    token.addGrant({
      roomJoin: true,
      room: roomName,
      canPublish: true,
      canSubscribe: true,
      canPublishData: true,
    });

    return new Response(JSON.stringify({
      server_url: wsUrl,
      token: await token.toJwt(),
      room: roomName,
      identity,
    }), { status: 200, headers: cors });
  } catch (error) {
    return new Response(JSON.stringify({ error: String(error?.message ?? error) }), { status: 500, headers: cors });
  }
});
