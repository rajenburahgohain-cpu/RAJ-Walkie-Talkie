# PTT wake backend

This function is the server-side design point for PTT wake notifications.

It must:

1. Authenticate the requesting Supabase user.
2. Verify the user is a member of the requested office.
3. Read registered FCM tokens for the other members.
4. Send a high-priority, user-visible `PTT_WAKE` message through FCM HTTP v1.
5. Never send audio through FCM.
6. Never put the Firebase service-account private key in the Android app.

Required server-side secrets:

- FIREBASE_PROJECT_ID
- FIREBASE_CLIENT_EMAIL
- FIREBASE_PRIVATE_KEY

The Android app only stores its own FCM registration token.
