-- Production FCM device registration for RAJ Walkie Talkie.
-- Run in the Supabase SQL editor for the configured project.
create table if not exists public.device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  token text not null unique,
  platform text not null default 'android',
  app_version text,
  updated_at timestamptz not null default now()
);

alter table public.device_tokens enable row level security;

drop policy if exists "device_tokens_select_own" on public.device_tokens;
create policy "device_tokens_select_own" on public.device_tokens
  for select using (auth.uid() = user_id);

drop policy if exists "device_tokens_insert_own" on public.device_tokens;
create policy "device_tokens_insert_own" on public.device_tokens
  for insert with check (auth.uid() = user_id);

drop policy if exists "device_tokens_update_own" on public.device_tokens;
create policy "device_tokens_update_own" on public.device_tokens
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "device_tokens_delete_own" on public.device_tokens;
create policy "device_tokens_delete_own" on public.device_tokens
  for delete using (auth.uid() = user_id);

create or replace function public.register_device_token(
  p_token text,
  p_platform text default 'android',
  p_app_version text default null
) returns void
language plpgsql
security invoker
set search_path = public
as $$
begin
  if auth.uid() is null or p_token is null or length(trim(p_token)) = 0 then
    raise exception 'Authentication and token are required';
  end if;
  insert into public.device_tokens(user_id, token, platform, app_version, updated_at)
  values(auth.uid(), trim(p_token), coalesce(p_platform,'android'), p_app_version, now())
  on conflict(token) do update set
    user_id = excluded.user_id,
    platform = excluded.platform,
    app_version = excluded.app_version,
    updated_at = now();
end;
$$;
