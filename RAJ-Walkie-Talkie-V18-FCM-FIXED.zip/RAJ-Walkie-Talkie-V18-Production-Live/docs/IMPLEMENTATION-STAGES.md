# V16 implementation stages

## Stage 1 — Native media engine
- Add LiveKit Android SDK.
- Create the Room in `VoiceForegroundService`.
- Keep the Room lifecycle independent of WebView.
- Use native microphone/speaker.
- Route PTT_DOWN/PTT_UP to `setMicrophoneEnabled`.

## Stage 2 — Token service
- Add Supabase Edge Function `livekit-token`.
- Validate Supabase access token.
- Validate office membership.
- Mint short-lived LiveKit token.
- Never expose LiveKit API secret to the app.

## Stage 3 — FCM wake
- Add Firebase Messaging SDK.
- Register each device FCM token with the backend.
- On PTT_DOWN, server sends high-priority PTT_WAKE to other office members.
- FCM handler starts/activates the voice foreground service only in Android-permitted
  cases.

## Stage 4 — Reconnect and recovery
- Keep one native Room per active office.
- Let LiveKit handle ICE/TURN/reconnect.
- Add a native watchdog for terminal DISCONNECTED states.
- On terminal failure, fetch a fresh token and create a fresh Room instance.
- Do not repeatedly call connect on the same failed Room object.

## Stage 5 — Remove WebRTC from index.html
- Delete the old RTCPeerConnection mesh.
- Delete Supabase voice broadcast signalling.
- Keep Supabase only for account/group/admin/backend functions.
- Keep UI PTT button, but route its commands to NativeBridge.

## Stage 6 — Production hardening
- Battery optimization guidance.
- Notification channel and Stop Voice action.
- Audio focus and phone-call handling.
- Crash logging.
- Connection metrics.
- Group-size load testing.
- Play Console Data Safety update for microphone, notifications, Firebase and realtime
  communication.
