# Why an SFU instead of the current P2P mesh

The current app creates a `RTCPeerConnection` to each active member. With N members,
a device can have N-1 peer connections and upload the same microphone audio separately
to multiple peers.

The production design uses an SFU. Each device publishes one audio stream to the SFU;
the SFU forwards the stream to subscribers. This is a better fit for office/group
walkie-talkie traffic and avoids keeping a WebRTC mesh alive inside a WebView.

LiveKit's Android SDK is native and its Room/RTCEngine includes network reconnection,
ICE/TURN support and server-side room routing. The native foreground service remains
the Android lifecycle owner.
