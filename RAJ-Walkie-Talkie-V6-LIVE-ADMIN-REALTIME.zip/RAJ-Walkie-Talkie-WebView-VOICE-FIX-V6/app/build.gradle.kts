plugins {
    id("com.android.application")
}
android {
    namespace = "com.raj.walkietalkie"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.raj.walkietalkie"
        minSdk = 23
        targetSdk = 36
        versionCode = 6
        versionName = "6.1"
    }
    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false; isShrinkResources = false }
    }
}
