package com.raj.walkietalkie;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int MIC_REQUEST_CODE = 1001;
    private static final String APP_URL =
            "https://rajenburahgohain-cpu.github.io/RAJ-Walkie-Talkie/";
    private static final String TRUSTED_ORIGIN =
            "https://rajenburahgohain-cpu.github.io";

    private WebView webView;
    private boolean pageReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        configureWebView();

        if (android.os.Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    MIC_REQUEST_CODE
            );
        }

        webView.loadUrl(APP_URL);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setLoadsImagesAutomatically(true);

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(0xFF000000);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep the app on the trusted HTTPS site.
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                installPttTouchGuard(view);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    String origin = request.getOrigin() == null
                            ? ""
                            : request.getOrigin().toString();

                    // Only allow microphone capture for the app's own trusted site.
                    if (!origin.startsWith(TRUSTED_ORIGIN)) {
                        request.deny();
                        return;
                    }

                    if (android.os.Build.VERSION.SDK_INT >= 23
                            && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestMicrophonePermissionAgain();
                        request.deny();
                        return;
                    }

                    List<String> allowed = new ArrayList<>();
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                            allowed.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE);
                        }
                    }

                    if (!allowed.isEmpty()) {
                        request.grant(allowed.toArray(new String[0]));
                    } else {
                        request.deny();
                    }
                });
            }
        });

        // Prevent long-press/context-menu interference with Press & Hold.
        webView.setOnLongClickListener(v -> true);
        webView.setHapticFeedbackEnabled(false);
    }

    private void requestMicrophonePermissionAgain() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            requestPermissions(
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    MIC_REQUEST_CODE
            );
        }
    }

    /**
     * The website already owns the WebRTC/PTT logic. This small injection only
     * prevents WebView gesture handling from stealing the PTT pointer.
     * It does not create a second voice/WebRTC implementation.
     */
    private void installPttTouchGuard(WebView view) {
        String js =
                "(function(){"
                + "var b=document.getElementById('pttBtn');"
                + "if(!b)return;"
                + "b.style.touchAction='none';"
                + "b.style.webkitUserSelect='none';"
                + "b.style.userSelect='none';"
                + "b.style.webkitTouchCallout='none';"
                + "b.addEventListener('contextmenu',function(e){e.preventDefault();},true);"
                + "})();";
        view.evaluateJavascript(js, null);
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MIC_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(
                        this,
                        "Microphone permission granted",
                        Toast.LENGTH_SHORT
                ).show();

                if (webView != null && pageReady) {
                    webView.reload();
                }
            } else {
                Toast.makeText(
                        this,
                        "Microphone permission is required for Voice/PTT",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}