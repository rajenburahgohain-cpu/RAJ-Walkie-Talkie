RAJ Walkie Talkie - WebView Voice Fix V3

Purpose:
- Keep the existing working GitHub Pages WebRTC voice implementation.
- Fix Android WebView microphone permission handling.
- Request Android RECORD_AUDIO permission at runtime.
- Grant WebView audio capture only for the trusted GitHub Pages origin.
- Prevent WebView long-press/context-menu gesture interference with Press & Hold.
- Keep JavaScript, DOM storage and WebRTC media playback enabled.

Trusted site:
https://rajenburahgohain-cpu.github.io/RAJ-Walkie-Talkie/

Build:
- Android Gradle Plugin 8.13.0
- Gradle 8.13
- compileSdk 36
- targetSdk 36
- minSdk 23

Important:
This V3 wrapper does not replace the website's Supabase/WebRTC code.
The website remains the voice engine.

Test order:
1. Uninstall the older RAJ Walkie Talkie debug APK.
2. Install the V3 debug APK.
3. Open the app and allow Microphone.
4. Log in and enter the same office on two phones.
5. On phone A, press and hold PTT continuously.
6. Confirm the button stays in TALKING/Transmitting state while the finger remains down.
7. Speak and verify phone B receives the audio.
8. Release the button and confirm transmission stops.

If the two phones work in Chrome but V3 still cannot capture audio,
check Android Settings > Apps > RAJ Walkie Talkie > Permissions > Microphone.