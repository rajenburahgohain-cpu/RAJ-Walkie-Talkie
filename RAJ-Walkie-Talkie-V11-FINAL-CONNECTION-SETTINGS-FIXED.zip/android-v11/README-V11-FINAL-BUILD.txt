RAJ Walkie Talkie V11 - Final Connection Settings Build

Included and preserved:
- Voice/PTT WebRTC communication
- START LIVE CONVERSATION
- Group Audio ON/OFF
- App-specific group volume
- Auto-Reconnect with Custom time
- Group Admin members/history/remove controls
- Google sign-in UI
- Phone-call state handling; group audio is muted during an active phone call
- Wi-Fi Settings
- Hotspot/Tethering Settings
- Bluetooth Settings
- GPS/Location Settings
- Internet/Network Settings
- Foreground microphone service and wake lock
- Privacy Policy
- Play Billing 9.1.0 scaffold updated for the current PendingPurchasesParams API

Build compatibility:
- compileSdk 36
- targetSdk 36
- minSdk 24 (required by androidx.webkit:webkit:1.17.0)
- Gradle 8.13
- Java 17

Note: This package has not been signed for Play production. Release signing / Play App Signing must be configured in the release pipeline or Play Console before production upload.

V11.0.1 BUILD FIX
- BillingManager now imports the public BillingClientStateListener interface directly.
- Hotspot settings uses the documented Android settings action string instead of the hidden ACTION_TETHER_SETTINGS SDK constant.
- minSdk remains 24 for androidx.webkit 1.17.0 compatibility.
