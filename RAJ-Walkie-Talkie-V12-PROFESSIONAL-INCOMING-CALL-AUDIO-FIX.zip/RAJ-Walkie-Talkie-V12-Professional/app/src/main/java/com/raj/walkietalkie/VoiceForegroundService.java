package com.raj.walkietalkie;

import android.app.*;
import android.content.*;
import android.os.IBinder;

public class VoiceForegroundService extends Service {
    private static final String CHANNEL="raj_voice";
    @Override public void onCreate(){ super.onCreate();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(android.os.Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"RAJ Voice",NotificationManager.IMPORTANCE_LOW));
        Intent i=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("RAJ Walkie Talkie").setContentText("Voice connection is active").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
        startForeground(1001,n);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){ return START_NOT_STICKY; }
    @Override public IBinder onBind(Intent intent){ return null; }
}
