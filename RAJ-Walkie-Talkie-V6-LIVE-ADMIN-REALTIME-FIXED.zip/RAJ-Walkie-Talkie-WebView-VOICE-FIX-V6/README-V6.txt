RAJ Walkie Talkie V6

Persistent voice/recovery update based on V5.

Features:
- Foreground microphone service + WakeLock
- Automatic Supabase Realtime reconnect
- WebRTC peer recovery after network changes
- Wi-Fi/mobile-data transition recovery
- Online/offline event recovery
- App resume recovery
- Periodic 15-second connection health check
- Saved active Office membership/session
- Existing QR, members, admin removal and history features retained

Note: Android/OEM force-stop, uninstall, revoked permissions, or total loss of Internet can still interrupt live voice. 24-hour operation is an engineering target, not an absolute guarantee.
