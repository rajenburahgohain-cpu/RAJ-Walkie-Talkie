# RAJ Walkie Talkie V13 – Play Billing 8 Final

V13 preserves the existing WebView/Supabase/WebRTC voice and Push-to-Talk implementation.

## Android release configuration
- versionCode: 13
- versionName: 13.0
- Play Billing Library: 8.0.0
- Kotlin runtime: 1.8.22
- Existing microphone / foreground voice service / WebRTC / PTT code preserved.

## Google Play note
The red Billing error shown for Version Code 12 belongs to the V12 AAB. This V13 project is Version Code 13 and explicitly uses Play Billing 8.0.0.

The deobfuscation message is a warning, not the Billing blocker.

Build the V13 release AAB from this source before uploading it to Internal testing.
