# RAJ Walkie Talkie — Play Store release checklist

## Included in this ZIP
- Target SDK 36 / Android 16 compatible build configuration.
- Release AAB build workflow.
- Google Play Billing Library 9.1.0 dependency scaffold.
- Local Privacy Policy page.
- HTTPS-only WebView configuration retained.
- Microphone foreground-service configuration retained.
- Working V10 voice/PTT code retained as the base for this release-prep build.
- Group Admin pricing/custom-plan controls removed from the UI.

## Still required in Play Console
- Create the app listing and complete required developer/account verification.
- Configure Play App Signing on the first release.
- Complete Data Safety and Content Rating forms accurately.
- Add the public Privacy Policy URL.
- Configure the subscription product/base plan if monetization is enabled.
- Test the release AAB on supported devices before production.

## Billing note
The Android Billing Library is included, but the real subscription product, base plan and price must be created in Play Console. Do not treat the placeholder product configuration as a live purchase product.
