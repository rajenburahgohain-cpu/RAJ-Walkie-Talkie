RAJ Walkie Talkie V10

Voice-first stability fix. Microphone capture is no longer started automatically when an office is selected or on page load. On Android WebView, microphone capture begins only after the user explicitly taps START LIVE CONVERSATION or presses PTT, reducing non-user-gesture audio-source failures.

Also keeps V9 WebView permission handling, QR, PTT, reconnect, and foreground microphone service fixes.
