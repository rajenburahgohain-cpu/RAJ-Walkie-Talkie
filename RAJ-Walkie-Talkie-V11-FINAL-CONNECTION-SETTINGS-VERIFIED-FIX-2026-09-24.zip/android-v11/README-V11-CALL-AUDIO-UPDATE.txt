RAJ Walkie Talkie V11 - Call Audio Safety Update

Added without removing the existing WebRTC/Supabase voice/PTT flow:
1. Native Android phone-call state monitoring (RINGING/OFFHOOK/IDLE).
2. During a normal mobile phone call, group microphone transmission is muted.
3. Group remote audio is muted while the phone call is active.
4. PTT is blocked while a phone call is active.
5. After the phone call ends, group audio/PTT can resume and auto-reconnect may run.
6. READ_PHONE_STATE runtime permission is requested for this feature.
7. Group Admin Panel now includes Auto-Reconnect time controls, including Custom 1-120 minutes.
8. Existing Custom Auto-Reconnect setting remains stored locally and is synchronized with the Group Admin Panel.

Important: Test normal incoming/outgoing SIM calls on the target Android phones. Android/OEM call-audio behavior can vary.

V11.2 Audio/Connection update
- Normal Android incoming phone calls retain the normal phone ringtone; the app mutes Group Voice and PTT during RINGING/OFFHOOK.
- Group Audio ON/OFF is per-device/user and does not disconnect the office connection.
- RAJ Walkie Talkie Group Voice has its own 0-100% volume control, separate from system volume.
- Office voice signalling now starts immediately when an Office is selected; microphone track remains disabled until Live Conversation/PTT.
- Internet/app-resume recovery attempts are immediate when Auto-Reconnect is enabled.
- Group Admin retains 30s/1m/2m/5m/10m and Custom 1-120 minute reconnect controls.
