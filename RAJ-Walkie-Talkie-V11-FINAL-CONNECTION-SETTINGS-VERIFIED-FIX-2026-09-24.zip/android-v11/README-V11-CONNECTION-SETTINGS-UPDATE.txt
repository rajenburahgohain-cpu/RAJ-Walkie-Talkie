RAJ Walkie Talkie V11 - Connection Settings Update

Included in this update:
- Wi-Fi Settings shortcut
- Hotspot/Tethering Settings shortcut
- Bluetooth Settings shortcut
- GPS/Location Settings shortcut
- Internet/Network Settings shortcut
- Existing Voice/PTT and Google sign-in code preserved
- Existing Group Audio and App Volume controls preserved
- Existing Auto-Reconnect controls preserved
- minSdk raised from 23 to 24 for androidx.webkit:webkit:1.17.0 compatibility

Important:
- Android system settings are opened by the app; the app does not silently toggle Wi-Fi, Hotspot, Bluetooth, or Location.
- The phone manufacturer may show a different Settings screen.
