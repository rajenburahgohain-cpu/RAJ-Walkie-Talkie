RAJ Walkie Talkie V11 - Final Connection Settings Build

Included and preserved:
- Voice/PTT WebRTC communication
- START LIVE CONVERSATION
- Group Audio ON/OFF
- App-specific group volume
- Auto-Reconnect with Custom time
- Group Admin members/history/remove controls
- Google sign-in UI
- Phone-call state handling; group audio is muted during an active phone call
- Wi-Fi Settings
- Hotspot/Tethering Settings
- Bluetooth Settings
- GPS/Location Settings
- Internet/Network Settings
- Foreground microphone service and wake lock
- Privacy Policy
- Play Billing 9.1.0 scaffold updated for the current PendingPurchasesParams API

Build compatibility:
- compileSdk 36
- targetSdk 36
- minSdk 24 (required by androidx.webkit:webkit:1.17.0)
- Gradle 8.13
- Java 17

Note: This package has not been signed for Play production. Release signing / Play App Signing must be configured in the release pipeline or Play Console before production upload.

V11.0.1 BUILD FIX
- BillingManager now imports the public BillingClientStateListener interface directly.
- Hotspot settings uses the documented Android settings action string instead of the hidden ACTION_TETHER_SETTINGS SDK constant.
- minSdk remains 24 for androidx.webkit 1.17.0 compatibility.

SOURCE VERIFICATION - 2026-09-24
- The GitHub failure shown in the build log is from stale source inside the ZIP used by the workflow:
  1) MainActivity.java still contains the hidden tethering Settings constant.
  2) BillingManager.java still contains the obsolete nested Billing listener reference.
- This verified package contains neither stale symbol.
- MainActivity.java uses the Android tethering action string with a wireless-settings fallback.
- BillingManager.java uses the public BillingClientStateListener interface.
- Google Play Billing 9.1.0 API usage was checked against the current Android Developers integration documentation.
- All existing V11 voice/PTT, reconnect, audio, admin, QR, Google sign-in, call-audio, and connection-settings assets are retained.
- Important: the repository's root GitHub Actions workflow must extract THIS ZIP filename; rerunning a workflow that still extracts an older ZIP will reproduce the same errors.

