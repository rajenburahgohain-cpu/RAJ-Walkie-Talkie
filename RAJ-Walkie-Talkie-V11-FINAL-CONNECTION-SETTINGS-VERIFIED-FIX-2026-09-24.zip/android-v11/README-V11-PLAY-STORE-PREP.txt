RAJ Walkie Talkie V11 — Play Store Prep

Voice safety:
- V10 working voice/PTT implementation is retained as the base.
- WebView microphone permission handling retained.
- Supabase Realtime/WebRTC voice flow retained.
- Foreground microphone service retained.

Release preparation included:
- targetSdk 36 / compileSdk 36
- versionCode 11 / versionName 11.0
- Play Billing Library 9.1.0 scaffold
- local Privacy Policy page
- Play Store release checklist
- AAB build workflow with Gradle 8.13
- Group Admin pricing/custom plan UI removed

Important:
The Billing Library being present does NOT create a live subscription. The subscription product/base plan and price must be configured in Play Console. The release AAB is not signed for production until Play App Signing/upload-key configuration is completed.
