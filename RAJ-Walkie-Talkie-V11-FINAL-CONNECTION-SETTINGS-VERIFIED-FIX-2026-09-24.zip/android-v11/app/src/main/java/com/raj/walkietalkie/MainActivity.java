package com.raj.walkietalkie;

import android.Manifest;
import android.app.Activity;
import android.media.AudioManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.provider.Settings;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebViewRenderProcess;
import android.webkit.WebViewRenderProcessClient;
import android.webkit.PermissionRequest;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int MIC_REQ = 5001;
    private static final int NOTIFICATION_REQ = 5002;
    private WebView webView;
    private PermissionRequest pendingWebPermissionRequest;
    private AudioManager audioManager;
    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    private static final String APP_HOST = "appassets.androidplatform.net";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (audioManager != null) {
            try { audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION); } catch (Exception ignored) {}
        }
        webView = new WebView(this);
        setContentView(webView);
        configure();
        setupPhoneCallStateListener();
        requestMicAndStartService();
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void configure() {
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setLoadsImagesAutomatically(true);
        s.setSupportZoom(false);
        if (Build.VERSION.SDK_INT >= 26) {
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
            webView.setWebViewRenderProcessClient(new WebViewRenderProcessClient() {
                @Override public void onRenderProcessUnresponsive(WebView view, WebViewRenderProcess renderer) {
                    // Keep the renderer alive; do not reload while a voice session is active.
                }
                @Override public void onRenderProcessResponsive(WebView view, WebViewRenderProcess renderer) { }
            });
        }

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return loader.shouldInterceptRequest(android.net.Uri.parse(url));
            }
        });

        webView.addJavascriptInterface(new NativeBridge(), "NativeBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }
        });

        webView.setOnLongClickListener(v -> true);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }


    private void handleWebPermissionRequest(final PermissionRequest request) {
        if (request == null) return;
        String host = "";
        try {
            if (request.getOrigin() != null) host = request.getOrigin().getHost();
        } catch (Exception ignored) {}

        if (!APP_HOST.equals(host) || request.getOrigin() == null ||
                !"https".equalsIgnoreCase(request.getOrigin().getScheme())) {
            request.deny();
            return;
        }

        java.util.ArrayList<String> allowed = new java.util.ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                allowed.add(resource);
            }
        }
        if (allowed.isEmpty()) {
            request.deny();
            return;
        }

        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingWebPermissionRequest = request;
            requestMicAndStartService();
            return;
        }

        request.grant(allowed.toArray(new String[0]));
        startVoiceService();
    }

    private void finishPendingWebPermissionRequest(boolean granted) {
        PermissionRequest request = pendingWebPermissionRequest;
        pendingWebPermissionRequest = null;
        if (request == null) return;
        if (!granted) {
            try { request.deny(); } catch (Exception ignored) {}
            return;
        }
        java.util.ArrayList<String> allowed = new java.util.ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                allowed.add(resource);
            }
        }
        if (allowed.isEmpty()) {
            try { request.deny(); } catch (Exception ignored) {}
        } else {
            try { request.grant(allowed.toArray(new String[0])); } catch (Exception ignored) {}
            startVoiceService();
        }
    }
    private void requestMicAndStartService() {
        if (Build.VERSION.SDK_INT >= 23) {
            boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            boolean phone = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
            if (!mic || !phone) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE}, MIC_REQ);
                return;
            }
        }
        startVoiceService();
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQ);
        }
    }

    private void startVoiceService() {
        Intent i = new Intent(this, VoiceForegroundService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_REQ) {
            boolean granted = Build.VERSION.SDK_INT < 23 ||
                    (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED);
            if (granted) {
                setupPhoneCallStateListener();
                startVoiceService();
            } else {
                Toast.makeText(this, "Microphone permission is required for Voice/PTT.", Toast.LENGTH_LONG).show();
            }
            finishPendingWebPermissionRequest(granted);
        }
    }

    private void setupPhoneCallStateListener() {
        telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (telephonyManager == null) return;
        phoneStateListener = new PhoneStateListener() {
            @Override public void onCallStateChanged(int state, String phoneNumber) {
                String s;
                if (state == TelephonyManager.CALL_STATE_RINGING) s = "RINGING";
                else if (state == TelephonyManager.CALL_STATE_OFFHOOK) s = "OFFHOOK";
                else s = "IDLE";
                // Let the normal Android phone app/ringtone own audio during calls.
                if (audioManager != null) {
                    try {
                        if (state == TelephonyManager.CALL_STATE_RINGING || state == TelephonyManager.CALL_STATE_OFFHOOK) {
                            audioManager.setMode(AudioManager.MODE_NORMAL);
                        } else {
                            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                        }
                    } catch (Exception ignored) {}
                }
                if (webView != null) {
                    final String js = "if(window.onNativePhoneCallState){window.onNativePhoneCallState('" + s + "');}";
                    runOnUiThread(() -> webView.evaluateJavascript(js, null));
                }
            }
        };
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            try { telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE); } catch (Exception ignored) {}
        }
    }

    private class NativeBridge {
        @JavascriptInterface public boolean phoneCallMonitoringAvailable() {
            return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface public void openWifiSettings() {
            openSystemSettings(Settings.ACTION_WIFI_SETTINGS);
        }

        @JavascriptInterface public void openHotspotSettings() {
            if (Build.VERSION.SDK_INT >= 24) {
                try {
                    openSystemSettings("android.settings.TETHER_SETTINGS");
                    return;
                } catch (Exception ignored) {}
            }
            openSystemSettings(Settings.ACTION_WIRELESS_SETTINGS);
        }

        @JavascriptInterface public void openBluetoothSettings() {
            openSystemSettings(Settings.ACTION_BLUETOOTH_SETTINGS);
        }

        @JavascriptInterface public void openLocationSettings() {
            openSystemSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        }

        @JavascriptInterface public void openInternetSettings() {
            openSystemSettings(Settings.ACTION_WIRELESS_SETTINGS);
        }

        @JavascriptInterface public void openAppSettings() {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(android.net.Uri.parse("package:" + getPackageName()));
            launchSettingsIntent(intent);
        }

        private void openSystemSettings(String action) {
            try {
                launchSettingsIntent(new Intent(action));
            } catch (Exception ignored) {
                launchSettingsIntent(new Intent(Settings.ACTION_SETTINGS));
            }
        }

        private void launchSettingsIntent(final Intent intent) {
            runOnUiThread(() -> {
                try {
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Settings screen এই device-ত available নহয়।", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (audioManager != null) { try { audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION); } catch (Exception ignored) {} }
    }

    @Override protected void onDestroy() {
        if (pendingWebPermissionRequest != null) {
            try { pendingWebPermissionRequest.deny(); } catch (Exception ignored) {}
            pendingWebPermissionRequest = null;
        }
        if (telephonyManager != null && phoneStateListener != null) {
            try { telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE); } catch (Exception ignored) {}
        }
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
