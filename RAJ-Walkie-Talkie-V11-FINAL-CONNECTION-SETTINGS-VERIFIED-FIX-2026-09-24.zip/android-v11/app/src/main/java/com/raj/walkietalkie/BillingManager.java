package com.raj.walkietalkie;

import android.app.Activity;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.PendingPurchasesParams;

/** Non-invasive Play Billing scaffold. Actual product/base-plan setup belongs in Play Console. */
public final class BillingManager {
    public static final String PREMIUM_PRODUCT_ID = "premium_monthly";
    private final BillingClient billingClient;

    public BillingManager(Activity activity) {
        billingClient = BillingClient.newBuilder(activity)
                .setListener((BillingResult result, java.util.List<com.android.billingclient.api.Purchase> purchases) -> { })
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
    }

    public void connect() {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult billingResult) { }
            @Override public void onBillingServiceDisconnected() { }
        });
    }

    public void close() {
        billingClient.endConnection();
    }
}
