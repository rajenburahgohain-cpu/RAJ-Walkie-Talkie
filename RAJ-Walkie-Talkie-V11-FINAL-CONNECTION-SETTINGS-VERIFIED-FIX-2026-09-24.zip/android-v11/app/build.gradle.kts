plugins {
    id("com.android.application")
}
android {
    namespace = "com.raj.walkietalkie"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.raj.walkietalkie"
        minSdk = 24
        targetSdk = 36
        versionCode = 11
        versionName = "11.0"
    }
    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false; isShrinkResources = false }
    }
    dependencies {
        implementation("androidx.webkit:webkit:1.17.0")
        // Google Play Billing integration scaffold. Product/base plan is configured in Play Console.
        implementation("com.android.billingclient:billing:9.1.0")
    }
}
