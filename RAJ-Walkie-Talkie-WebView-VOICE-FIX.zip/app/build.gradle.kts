plugins {
    id("com.android.application")
}

android {
    namespace = "com.raj.walkietalkie"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.raj.walkietalkie"
        minSdk = 23
        targetSdk = 36
        versionCode = 5
        versionName = "5.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
