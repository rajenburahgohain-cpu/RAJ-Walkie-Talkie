plugins {
    id("com.android.application")
}
android {
    namespace = "com.raj.walkietalkie"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.raj.walkietalkie"
        minSdk = 23
        targetSdk = 36
        versionCode = 10
        versionName = "10.0"
    }
    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false; isShrinkResources = false }
    }
    dependencies {
        implementation("androidx.webkit:webkit:1.17.0")
    }
}
